package Pages;

import com.baseconfig.Base;

public class HotelsPage extends Base {

}
