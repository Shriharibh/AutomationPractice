package Pages;

import com.baseconfig.Base;

public class BlogPage extends Base {

}
