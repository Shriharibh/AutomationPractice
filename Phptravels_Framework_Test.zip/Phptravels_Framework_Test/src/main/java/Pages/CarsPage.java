package Pages;

import com.baseconfig.Base;

public class CarsPage extends Base {

}
