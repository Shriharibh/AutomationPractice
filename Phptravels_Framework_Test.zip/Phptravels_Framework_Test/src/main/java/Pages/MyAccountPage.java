package Pages;

import com.baseconfig.Base;

public class MyAccountPage extends Base {

}
