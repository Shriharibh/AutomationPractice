package Pages;

import com.baseconfig.Base;

public class ToursPage extends Base {

}
