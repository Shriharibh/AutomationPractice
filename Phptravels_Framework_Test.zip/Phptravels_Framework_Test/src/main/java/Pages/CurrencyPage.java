package Pages;

import com.baseconfig.Base;

public class CurrencyPage extends Base {

}
