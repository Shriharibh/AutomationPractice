package Pages;

import com.baseconfig.Base;

public class OffersPage extends Base {

}
